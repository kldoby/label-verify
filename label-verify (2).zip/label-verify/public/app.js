const state = {
  items: [], // { id, file, previewUrl, application: {...}, result: null, status }
};

const fileInput = document.getElementById("file-input");
const dropzone = document.getElementById("dropzone");
const csvInput = document.getElementById("csv-input");
const queuePanel = document.getElementById("queue-panel");
const queueList = document.getElementById("queue-list");
const queueCount = document.getElementById("queue-count");
const verifyAllBtn = document.getElementById("verify-all");
const resultsPanel = document.getElementById("results-panel");
const resultsList = document.getElementById("results-list");
const resultsSummary = document.getElementById("results-summary");
const exportBtn = document.getElementById("export-csv");

let csvByFilename = {};

// ---------- Intake ----------

dropzone.addEventListener("click", () => fileInput.click());
dropzone.addEventListener("keydown", (e) => {
  if (e.key === "Enter" || e.key === " ") fileInput.click();
});
["dragover", "dragenter"].forEach((evt) =>
  dropzone.addEventListener(evt, (e) => {
    e.preventDefault();
    dropzone.classList.add("dragover");
  })
);
["dragleave", "drop"].forEach((evt) =>
  dropzone.addEventListener(evt, (e) => {
    e.preventDefault();
    dropzone.classList.remove("dragover");
  })
);
dropzone.addEventListener("drop", (e) => {
  const files = Array.from(e.dataTransfer.files).filter((f) => f.type.startsWith("image/"));
  addFiles(files);
});
fileInput.addEventListener("change", (e) => {
  addFiles(Array.from(e.target.files));
  fileInput.value = "";
});

csvInput.addEventListener("change", async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const text = await file.text();
  csvByFilename = parseCsv(text);
  // backfill any already-added items
  state.items.forEach((item) => {
    const match = csvByFilename[item.file.name];
    if (match) Object.assign(item.application, match);
  });
  renderQueue();
});

function parseCsv(text) {
  const lines = text.trim().split(/\r?\n/);
  const headers = lines[0].split(",").map((h) => h.trim());
  const byFilename = {};
  for (let i = 1; i < lines.length; i++) {
    const cells = lines[i].split(",").map((c) => c.trim());
    const row = {};
    headers.forEach((h, idx) => (row[h] = cells[idx] || ""));
    if (row.filename) byFilename[row.filename] = row;
  }
  return byFilename;
}

function addFiles(files) {
  if (!files.length) return;
  files.forEach((file) => {
    const id = `${file.name}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const csvMatch = csvByFilename[file.name] || {};
    state.items.push({
      id,
      file,
      previewUrl: URL.createObjectURL(file),
      application: {
        brand_name: csvMatch.brand_name || "",
        class_type: csvMatch.class_type || "",
        alcohol_content: csvMatch.alcohol_content || "",
        net_contents: csvMatch.net_contents || "",
      },
      result: null,
      status: "queued",
    });
  });
  queuePanel.hidden = false;
  renderQueue();
}

function renderQueue() {
  queueList.innerHTML = "";
  state.items.forEach((item) => {
    const row = document.createElement("div");
    row.className = "queue-item";
    row.innerHTML = `
      <img src="${item.previewUrl}" alt="" />
      <div>
        <div class="queue-filename">${escapeHtml(item.file.name)}</div>
        <div class="queue-fields">
          ${fieldInput(item.id, "brand_name", "Brand name", item.application.brand_name)}
          ${fieldInput(item.id, "class_type", "Class / type", item.application.class_type)}
          ${fieldInput(item.id, "alcohol_content", "Alcohol content", item.application.alcohol_content)}
          ${fieldInput(item.id, "net_contents", "Net contents", item.application.net_contents)}
        </div>
      </div>
    `;
    queueList.appendChild(row);
  });
  queueCount.textContent = `${state.items.length} label${state.items.length === 1 ? "" : "s"} queued`;

  queueList.querySelectorAll("input[data-field]").forEach((input) => {
    input.addEventListener("input", (e) => {
      const item = state.items.find((i) => i.id === e.target.dataset.id);
      if (item) item.application[e.target.dataset.field] = e.target.value;
    });
  });
}

function fieldInput(id, field, label, value) {
  return `<label>${label}<input data-id="${id}" data-field="${field}" value="${escapeHtml(value)}" placeholder="As written on the application" /></label>`;
}

function escapeHtml(s) {
  return String(s || "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

// ---------- Verification ----------

verifyAllBtn.addEventListener("click", runBatch);

async function runBatch() {
  verifyAllBtn.disabled = true;
  verifyAllBtn.textContent = "Checking…";
  resultsPanel.hidden = false;
  resultsList.innerHTML = "";

  const CONCURRENCY = 5;
  const queue = [...state.items];
  const placeholders = new Map();

  state.items.forEach((item) => {
    const card = document.createElement("div");
    card.className = "result-card";
    card.innerHTML = `<div class="result-card-head"><img src="${item.previewUrl}" alt="" /><span class="name">${escapeHtml(item.file.name)}</span><span class="timing">checking…</span></div>`;
    resultsList.appendChild(card);
    placeholders.set(item.id, card);
  });

  let active = 0;
  let idx = 0;
  await new Promise((resolve) => {
    function next() {
      if (idx >= queue.length && active === 0) return resolve();
      while (active < CONCURRENCY && idx < queue.length) {
        const item = queue[idx++];
        active++;
        verifyOne(item)
          .then((result) => renderResult(item, placeholders.get(item.id), result))
          .catch((err) => renderError(item, placeholders.get(item.id), err))
          .finally(() => {
            active--;
            next();
          });
      }
    }
    next();
  });

  verifyAllBtn.disabled = false;
  verifyAllBtn.textContent = "Check all labels";
  renderSummary();
}

async function verifyOne(item) {
  const resizedBlob = await resizeImage(item.file, 1600, 0.85);
  const formData = new FormData();
  formData.append("image", resizedBlob, item.file.name);
  formData.append("application", JSON.stringify(item.application));

  const res = await fetch("/api/verify", { method: "POST", body: formData });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Server error (${res.status})`);
  }
  const result = await res.json();
  item.result = result;
  item.status = "done";
  return result;
}

function resizeImage(file, maxDim, quality) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      let { width, height } = img;
      if (width > maxDim || height > maxDim) {
        const scale = maxDim / Math.max(width, height);
        width = Math.round(width * scale);
        height = Math.round(height * scale);
      }
      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;
      canvas.getContext("2d").drawImage(img, 0, 0, width, height);
      canvas.toBlob((blob) => resolve(blob), "image/jpeg", quality);
    };
    img.onerror = reject;
    img.src = URL.createObjectURL(file);
  });
}

// ---------- Rendering ----------

function statusClass(status) {
  if (status === "match" || status === "pass") return "pass";
  if (status === "review") return "review";
  return "fail";
}
function stampFor(item) {
  const r = item.result;
  const allStatuses = (r.comparisons || []).map((c) => c.status).concat(r.government_warning.match ? "pass" : "fail");
  if (allStatuses.includes("mismatch") || allStatuses.includes("fail")) return { cls: "fail", label: "Needs correction" };
  if (allStatuses.includes("review")) return { cls: "review", label: "Needs a look" };
  return { cls: "pass", label: "Clear" };
}

function renderResult(item, card, result) {
  const stamp = stampFor(item);
  const fieldLabels = {
    brand_name: "Brand name",
    class_type: "Class / type",
    alcohol_content: "Alcohol content",
    net_contents: "Net contents",
  };

  const rows = (result.comparisons || [])
    .map((c) => {
      const cls = statusClass(c.status);
      return `
        <div class="field-row">
          <div class="field-label">${fieldLabels[c.field] || c.field}</div>
          <div class="field-value">${escapeHtml(c.application_value)}</div>
          <div class="field-value">${escapeHtml(c.label_value)}</div>
          <div class="field-status"><span class="dot ${cls}"></span>${cls === "pass" ? "Match" : cls === "review" ? "Review" : "Mismatch"}</div>
          ${c.note ? `<div class="field-note">${escapeHtml(c.note)}</div>` : ""}
        </div>`;
    })
    .join("");

  const warningCls = result.government_warning.match ? "pass" : "fail";
  const warningRow = `
    <div class="field-row">
      <div class="field-label">Government Warning</div>
      <div class="field-value">required text</div>
      <div class="field-value"></div>
      <div class="field-status"><span class="dot ${warningCls}"></span>${result.government_warning.match ? "Match" : "Mismatch"}</div>
      <div class="field-note">${escapeHtml(result.government_warning.note)}</div>
    </div>`;

  const qualityNote = result.image_quality_issue
    ? `<div class="quality-note">Image quality flag — ${escapeHtml(result.image_quality_issue)}</div>`
    : "";

  card.innerHTML = `
    <div class="result-card-head">
      <img src="${item.previewUrl}" alt="" />
      <span class="name">${escapeHtml(item.file.name)}</span>
      <span class="stamp ${stamp.cls}">${stamp.label}</span>
      <span class="timing">${result.elapsed_ms} ms</span>
    </div>
    ${qualityNote}
    <div class="field-rows">${rows}${warningRow}</div>
  `;
}

function renderError(item, card, err) {
  card.innerHTML = `
    <div class="result-card-head">
      <img src="${item.previewUrl}" alt="" />
      <span class="name">${escapeHtml(item.file.name)}</span>
      <span class="stamp fail">Couldn't check</span>
    </div>
    <div class="quality-note">${escapeHtml(err.message || "Something went wrong reaching the server.")}</div>
  `;
}

function renderSummary() {
  const done = state.items.filter((i) => i.result);
  const clear = done.filter((i) => stampFor(i).cls === "pass").length;
  const review = done.filter((i) => stampFor(i).cls === "review").length;
  const fail = done.filter((i) => stampFor(i).cls === "fail").length;
  resultsSummary.textContent = `${clear} clear · ${review} need a look · ${fail} need correction`;
}

exportBtn.addEventListener("click", () => {
  const rows = [["filename", "field", "application_value", "label_value", "status", "note"]];
  state.items.forEach((item) => {
    if (!item.result) return;
    (item.result.comparisons || []).forEach((c) => {
      rows.push([item.file.name, c.field, c.application_value, c.label_value, c.status, c.note || ""]);
    });
    rows.push([item.file.name, "government_warning", "", "", item.result.government_warning.match ? "match" : "mismatch", item.result.government_warning.note]);
  });
  const csv = rows.map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "label-review-results.csv";
  a.click();
});
