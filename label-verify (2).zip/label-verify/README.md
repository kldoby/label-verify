# Label Review Desk

A prototype that checks alcohol beverage label artwork against the values
submitted in a TTB label application — built to take the routine "does the
form match the label" work off agents' plates while leaving judgment calls
to a human.

See [`ARCHITECTURE.md`](./ARCHITECTURE.md) for the full design rationale
(latency strategy, batch handling, accessibility, firewall considerations)
and [`STRATEGY.md`](./STRATEGY.md) for how this addresses specific
stakeholder concerns raised in discovery.

## What it does

1. Drop in one or more label photos (and optionally a CSV of the matching
   application values).
2. Confirm or fill in what each label *should* say.
3. Click **Check all labels**. Each label gets a single AI-assisted check —
   brand name, class/type, alcohol content, net contents, and a strict,
   separately-verified check of the Government Warning statement.
4. Review results as a traffic-light list (clear / needs a look / needs
   correction) and export to CSV.

Cosmetic differences (e.g. `"STONE'S THROW"` vs `"Stone's Throw"`) are
flagged as **review**, not **mismatch** — the tool surfaces them for a human
to glance at rather than silently passing or hard-failing them.

## Setup

### Requirements
- Node.js 18+
- An Anthropic API key with access to a vision-capable Claude model

### Install & run

```bash
cd server
npm install
cp .env.example .env   # then add your ANTHROPIC_API_KEY
npm start
```

The server runs on `http://localhost:8787` by default and also serves the
frontend in `/public`. Open that URL in a browser.

### Environment variables

| Variable | Description |
|---|---|
| `ANTHROPIC_API_KEY` | Required. API key for the vision model call. |
| `PORT` | Optional, defaults to `8787`. |

## Deploying

This is a single small Node service with no database, so it deploys
cleanly to Render, Fly.io, Railway, or an Azure App Service:

1. Push this repo.
2. Create a new web service pointing at `server/` with `npm install` as the
   build command and `npm start` as the run command.
3. Set the `ANTHROPIC_API_KEY` environment variable in the platform's
   dashboard.
4. The platform serves the static frontend from `/public` via the same
   Express app — no separate static hosting needed.

## Approach, tools, and assumptions

**Approach:** a single multimodal LLM call per label does extraction and
comparison together (see `ARCHITECTURE.md` for why this beats a
traditional OCR-then-rules pipeline for both speed and handling imperfect
photos). The one exception is the Government Warning, which is checked
with a strict, case-sensitive string comparison in code — that field has
zero tolerance per the discovery notes, so it isn't left to a model's
judgment.

**Tools:** Node.js + Express backend, Anthropic API (vision-enabled Claude
model) for label reading, plain HTML/CSS/JS frontend with no build step.

**Assumptions made, explicitly:**
- This is a standalone prototype, not a COLA-integrated tool — per Marcus,
  that integration is a separate, later effort with its own authorization
  requirements.
- No PII or images are persisted; everything is processed in memory and
  discarded after the response. A production version would need a real
  retention policy.
- The prototype calls a cloud API directly. A production deployment behind
  TTB's firewall would need that domain allowlisted, or the model hosted
  inside the network's trust boundary — flagged as a follow-up decision,
  not solved here.
- "5 seconds" is treated as a per-label target validated by the elapsed-time
  shown on each result card, not a number assumed without checking.
- Test labels were generated rather than sourced from real applications,
  per the project's suggestion to use AI image generation for samples.

## Known limitations

- CSV batch matching is by filename, so filenames need to correspond
  between the images and the manifest.
- Country-of-origin and bottler name/address fields are not yet covered —
  the schema (`FIELD_SCHEMA` in `server/index.js`) is the place to extend
  this to the full TTB field set per beverage type.
- No retry/backoff on individual label failures within a batch yet — a
  failed label is reported as "couldn't check" rather than auto-retried.
