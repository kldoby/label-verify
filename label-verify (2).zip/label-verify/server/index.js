/**
 * Label Verification Prototype — Backend
 *
 * One endpoint: POST /api/verify
 * Accepts a label image + the submitted application field values,
 * makes a single multimodal call to extract label text and compare it
 * against the application, then runs a deterministic exact-match check
 * on the Government Warning before returning a structured result.
 *
 * No image or extracted data is persisted — everything is handled
 * in memory for the lifetime of the request.
 */

require("dotenv").config();
const path = require("path");
const express = require("express");
const cors = require("cors");
const multer = require("multer");
const Anthropic = require("@anthropic-ai/sdk");

const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 8 * 1024 * 1024 } });

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// Built React app output (created by `npm run build` in /client).
const CLIENT_DIST = path.join(__dirname, "..", "client", "dist");

app.use(cors());
app.use(express.json({ limit: "2mb" }));
app.use(express.static(CLIENT_DIST));

// The exact canonical Government Warning text, per 27 CFR 16.21.
// This is the one field we do NOT trust to the model's judgment —
// it's checked with a strict, case-sensitive comparison in code.
const CANONICAL_WARNING =
  "GOVERNMENT WARNING: (1) ACCORDING TO THE SURGEON GENERAL, WOMEN SHOULD NOT DRINK ALCOHOLIC BEVERAGES DURING PREGNANCY BECAUSE OF THE RISK OF BIRTH DEFECTS. (2) CONSUMPTION OF ALCOHOLIC BEVERAGES IMPAIRS YOUR ABILITY TO DRIVE A CAR OR OPERATE MACHINERY, AND MAY CAUSE HEALTH PROBLEMS.";

function normalizeForExactCompare(text) {
  // Collapse whitespace only — do NOT touch case or punctuation,
  // since both are compliance-relevant for this specific field.
  return (text || "").replace(/\s+/g, " ").trim();
}

function checkGovernmentWarning(extractedWarningText) {
  const extracted = normalizeForExactCompare(extractedWarningText);
  const canonical = normalizeForExactCompare(CANONICAL_WARNING);

  if (!extracted) {
    return { match: false, severity: "fail", note: "No Government Warning text was found on the label." };
  }
  if (extracted === canonical) {
    return { match: true, severity: "pass", note: "Exact match." };
  }
  if (extracted.toUpperCase() === canonical.toUpperCase() && extracted !== canonical) {
    return {
      match: false,
      severity: "fail",
      note: "Wording matches but capitalization is wrong — the warning must be in all caps.",
    };
  }
  return {
    match: false,
    severity: "fail",
    note: "Warning text does not match the required wording exactly.",
  };
}

const FIELD_SCHEMA = `
Return ONLY valid JSON, no other text, in exactly this shape:
{
  "extracted": {
    "brand_name": "string as it appears on the label",
    "class_type": "string as it appears on the label",
    "alcohol_content": "string as it appears on the label",
    "net_contents": "string as it appears on the label",
    "government_warning": "the full government warning text, verbatim, exactly as printed on the label including punctuation and capitalization"
  },
  "comparisons": [
    {
      "field": "brand_name",
      "application_value": "string",
      "label_value": "string",
      "status": "match" | "review" | "mismatch",
      "note": "short plain-language explanation, e.g. note a case-only or punctuation-only difference as 'review' not 'mismatch'"
    }
  ],
  "image_quality_issue": "string or null — note if glare, angle, or blur prevented reading any field"
}
Use "review" (not "mismatch") for cosmetic differences a human would consider the same thing
(e.g. "STONE'S THROW" vs "Stone's Throw", extra spacing, a trailing period).
Use "mismatch" only for genuine factual discrepancies (different ABV, different brand, missing field).
Do not include a comparison entry for government_warning — that is checked separately.
`;

app.post("/api/verify", upload.single("image"), async (req, res) => {
  const startedAt = Date.now();
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No image was uploaded." });
    }

    let application;
    try {
      application = JSON.parse(req.body.application || "{}");
    } catch {
      return res.status(400).json({ error: "Application data was not valid JSON." });
    }

    const imageBase64 = req.file.buffer.toString("base64");
    const mediaType = req.file.mimetype || "image/jpeg";

    const message = await anthropic.messages.create({
      model: "claude-haiku-4-5-20251001",
      max_tokens: 700,
      messages: [
        {
          role: "user",
          content: [
            { type: "image", source: { type: "base64", media_type: mediaType, data: imageBase64 } },
            {
              type: "text",
              text:
                `You are checking an alcohol beverage label against the values submitted in a TTB label application.\n\n` +
                `Application values:\n${JSON.stringify(application, null, 2)}\n\n` +
                FIELD_SCHEMA,
            },
          ],
        },
      ],
    });

    const raw = message.content.map((b) => (b.type === "text" ? b.text : "")).join("");
    const cleaned = raw.replace(/```json|```/g, "").trim();
    let parsed;
    try {
      parsed = JSON.parse(cleaned);
    } catch (e) {
      return res.status(502).json({ error: "Could not parse model response.", raw });
    }

    const warningResult = checkGovernmentWarning(parsed.extracted?.government_warning);

    const elapsedMs = Date.now() - startedAt;

    res.json({
      filename: req.file.originalname,
      elapsed_ms: elapsedMs,
      extracted: parsed.extracted,
      comparisons: parsed.comparisons || [],
      government_warning: warningResult,
      image_quality_issue: parsed.image_quality_issue || null,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Verification failed.", detail: err.message });
  }
});

app.get("/api/health", (req, res) => res.json({ ok: true }));

// Anything that isn't an API route falls through to the React app,
// so client-side refreshes and deep links don't 404.
app.get(/^(?!\/api).*/, (req, res) => {
  res.sendFile(path.join(CLIENT_DIST, "index.html"));
});

const PORT = process.env.PORT || 8787;
app.listen(PORT, () => console.log(`Label verification server running on port ${PORT}`));
