# Architecture & Design Rationale

## 1. The core pipeline

```
[Label image(s)]  ──┐
                     ├──► Single multimodal LLM call ──► Structured JSON
[Application data] ──┘      (extract + compare)            {field, app_value,
                                                              label_value, match,
                                                              confidence, note}
                                                                   │
                                                                   ▼
                                                   Deterministic post-checks
                                                   (exact-match Government
                                                    Warning rule, in code —
                                                    not left to the model)
                                                                   │
                                                                   ▼
                                                        Traffic-light UI result
                                                     ✅ match / 🟡 review / ❌ mismatch
```

**Why one LLM call instead of OCR-then-rules-engine:**
- One round trip, not a chain → directly serves the 5-second requirement.
- A vision-capable model reads labels that are angled, glared, or poorly lit (Jenny's ask) far better than a traditional OCR engine, without a separate "enhance image" step.
- It can apply judgment the way Dave does — "STONE'S THROW" vs "Stone's Throw" — by reporting it as a **case-only variation**, not a hard fail, instead of a brittle regex that would reject it.

**Why a deterministic check sits on top, not inside, the model call:**
- Jenny was explicit: the Government Warning has to match **exactly**, including the all-caps, bolded "GOVERNMENT WARNING:" lead-in. That's a compliance-critical, zero-tolerance rule. We don't want a model's "close enough" instinct anywhere near it.
- The model's job is narrow: extract the warning text verbatim as it appears on the label. The code then does a strict, case-sensitive string comparison against the canonical statement. If the model mis-extracts, that's a bug to fix in extraction — not a tolerance to loosen in the rule.

## 2. Meeting the 5-second constraint

The scanning vendor pilot failed because a single label took 30-40 seconds. Three choices specifically target that:

1. **Fast model tier.** Use the smallest/fastest multimodal model that's reliably accurate for this (e.g. Claude Haiku-class), not the largest model available. Accuracy-per-second matters more here than peak accuracy.
2. **Small, constrained output.** The model returns a short structured JSON object (handful of fields), not freeform prose — this caps generation time directly, since output length dominates latency for these models.
2. **Client-side image prep.** Resize/compress images in the browser before upload (e.g. cap at ~1600px on the long edge, JPEG quality ~85%). Large phone photos add upload and inference time for no accuracy benefit.
4. **One call, not several.** No "extract, then verify, then summarize" chain — that's three round trips disguised as one feature.

Realistic target: ~2-4 seconds per label on a fast model with a small image. This is validated, not assumed — the prototype logs per-call latency so it can be checked against real labels.

## 3. Batch handling (Sarah/Janet's 200-300 label case)

- Multi-file selection or drag-and-drop of a whole folder, plus an optional CSV manifest (`filename, brand_name, class_type, abv, net_contents`) so applications don't have to be typed in one at a time.
- If no manifest is provided, the UI lets an agent fill in expected values per image inline.
- Jobs run with a **concurrency cap** (default 5 in flight at once) rather than one-at-a-time or all-at-once — fast enough to clear 200 labels in a couple of minutes, without hammering the API or the firewall.
- Batch results render as a single sortable/filterable table (status, label, mismatches) with CSV export, so an agent can scan for the handful that need a human look instead of opening 300 individual screens.

## 4. Accessibility ("my mother could figure it out")

- One linear path: **drop files → review pre-filled or typed expected values → Verify → see results.** No settings screens, no nested menus.
- Plain traffic-light status (green check, amber "needs a look," red mismatch) instead of scores or confidence percentages as the primary signal — the number is available on hover/expand for agents like Jenny who want it, but it's not required to use the tool.
- Large click targets, sentence-case plain-language labels and errors ("Couldn't read the alcohol content on this image — try a clearer photo" rather than "OCR_CONFIDENCE_LOW").
- Keyboard-navigable and screen-reader labeled, since some agents may use assistive tech.

## 5. Network / firewall reality (Marcus's constraint)

The prototype calls a cloud LLM API over HTTPS, which is the single outbound dependency. This is flagged explicitly as a **prototype assumption**, not a production decision:

- For the take-home, this is fine — it's a standalone proof of concept, not a COLA integration.
- For a real deployment behind TTB's firewall, this domain would need an explicit allowlist entry (the scanning vendor pilot failed partly because this never happened), **or** the model would need to run on infrastructure already inside the trust boundary (e.g. a vision model hosted in TTB's own Azure tenant). That tradeoff — and its cost/timeline — is a procurement question, not a prototype question, and is called out as a follow-up rather than solved here.

## 6. Data handling

- No images or extracted field data are persisted to disk or a database in the prototype — everything is processed in memory per request and discarded after the response is returned to the browser.
- This sidesteps PII/retention policy questions for now (Marcus: "we're not storing anything sensitive for this exercise"), but is explicitly flagged as a gap a production version would need to close (audit trail, retention schedule, access controls).

## 7. Tech stack

| Layer | Choice | Why |
|---|---|---|
| Backend | Node.js + Express | Minimal, fast to stand up, easy to deploy anywhere (Render/Fly/Azure App Service) |
| Vision/LLM | Anthropic API (Claude, vision-enabled) | Single-call extract+compare with judgment-aware reasoning |
| Frontend | Vanilla HTML/CSS/JS | No build step, no framework overhead — lighter, faster to load, and one less thing to break on government hardware/browsers |
| Image handling | Client-side canvas resize before upload | Keeps payloads small for latency and works within typical upload limits |

## 8. Out of scope (explicitly, per Marcus)

- COLA integration / authentication — standalone tool only.
- Production security hardening, audit logging, retention policy — prototype only.
- This is meant to *inform* a future procurement decision, not be the production system.
