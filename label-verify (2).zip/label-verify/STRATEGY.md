# Stakeholder Talking Points

How specific decisions in this prototype map back to what people said in
discovery — useful for a presentation or design-review conversation.

## Dave's "judgment" concern (STONE'S THROW vs Stone's Throw)

> "Technically a mismatch? Sure. But it's obviously the same thing. You
> need judgment."

The tool has a third status, not just pass/fail: **review**. Cosmetic
differences in case, punctuation, or spacing land here instead of being
auto-rejected or silently passed. It's a deliberate middle ground —
the tool isn't trying to replace Dave's judgment, it's trying to put the
right handful of cases in front of him instead of making him re-check
all 150,000 line by line. The Government Warning is the one exception:
it's checked with zero tolerance, because that field's exactness is a
compliance requirement, not a stylistic one — Jenny was explicit about that.

**Talking point:** "We didn't ask the model to be the judgment call —
we asked it to flag the close-but-not-identical cases for a human, and
to apply the same zero-tolerance rule to the Warning that Jenny does."

## Jenny's warning-statement strictness

> "It has to be exact. Word-for-word... all caps and bold... I caught one
> last month where they used 'Government Warning' in title case."

This is the one field handled with a deterministic, case-sensitive string
comparison in application code — not the AI model's judgment. The model's
only job for this field is to transcribe what's printed on the label
verbatim; the comparison against the canonical, legally-required wording
happens afterward, in code that doesn't have an "approximately right"
setting.

**Talking point:** "If this rule ever needs to be loosened or the
canonical text changes, that's a one-line code change we can show you —
it's not buried in a model's behavior where it's hard to verify."

## The 5-second requirement (scanning vendor pilot failure)

> "If we can't get results back in about 5 seconds, nobody's going to use
> it. We learned that the hard way."

Three concrete choices target this: a fast model tier instead of the
largest available, a small structured JSON response instead of freeform
output, and client-side image resizing before upload so large phone photos
don't add unnecessary latency. Each label's actual elapsed time is shown
on its result card — this isn't a number being assumed, it's something
that gets validated against real test labels and can be shown live.

**Talking point:** "We can show you the timer on screen, label by label,
rather than asking you to trust a number in a slide deck."

## Accessibility for a 50+, mixed-tech-comfort team

> "We need something my mother could figure out... Clean, obvious, no
> hunting for buttons."

One linear flow — drop files, confirm fields, check, review — with no
settings screens or nested menus. Status is shown as plain traffic-light
language ("Clear" / "Needs a look" / "Needs correction") rather than
scores or jargon, with large click targets and sentence-case copy
throughout.

**Talking point:** "Dave and Jenny can use the exact same screen — there's
no advanced mode to discover or a setting Dave would need Jenny to show
him."

## Batch processing for peak season (Janet, Seattle office)

> "We literally have to process them one at a time... if there was some way
> to handle batch uploads, that would be huge."

Multi-file drop with an optional CSV manifest for the application values,
processed with a concurrency cap so 200-300 labels clear in a couple of
minutes rather than serially. Results land in one sortable table with CSV
export, so the review step is "scan for the few flagged rows," not "open
300 screens."

**Talking point:** "This is the single feature most directly worth
demoing to Janet — bring a folder of test labels and watch the whole
batch clear."

## Imperfect photos (Jenny's "out of scope, but...")

> "It would be amazing if the tool could handle images that aren't
> perfectly shot."

Using a vision-capable model rather than traditional OCR was partly chosen
for this reason — it tolerates angle, glare, and uneven lighting far
better than a rules-based scanner. When a field genuinely can't be read,
the tool says so in plain language (e.g. "Couldn't read the alcohol
content on this image") instead of guessing or silently failing, and
flags it for the agent to request a clearer photo — which is exactly
today's process, just narrowed to the labels that actually need it.

**Talking point:** "This was framed as a stretch goal, but it came nearly
for free from the model choice that already solved the latency
requirement — worth mentioning since it wasn't asked for."

## Marcus's firewall and infrastructure concerns

> "Our network blocks outbound traffic to a lot of domains... half their
> features didn't work because our firewall blocked connections to their
> ML endpoints."

The prototype is explicit that it has exactly one outbound dependency (the
model API), and that this is a known, named assumption rather than
something discovered the hard way during a pilot. The README and
architecture doc both call out that a production rollout would need either
a firewall allowlist entry for that one domain, or the model hosted inside
TTB's own network boundary — and that this is a procurement/IT decision to
make deliberately, not a surprise to hit later.

**Talking point:** "We're flagging this up front so it's a planned decision
next time, not a repeat of the vendor pilot."

## Framing the whole thing with Marcus's "standalone, not COLA" scope

> "We're not looking to integrate with COLA directly... think of this as a
> standalone proof-of-concept."

Worth saying explicitly in any walkthrough: this tool doesn't touch COLA,
doesn't require its authorization work, and isn't claiming to be
production-ready. It's scoped exactly the way Marcus described it — a
proof of concept that can inform a future procurement decision, with the
production gaps (retention policy, audit logging, COLA integration, network
placement) named rather than glossed over.
