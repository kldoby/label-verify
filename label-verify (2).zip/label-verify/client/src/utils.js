export function parseCsv(text) {
  const lines = text.trim().split(/\r?\n/);
  const headers = lines[0].split(",").map((h) => h.trim());
  const byFilename = {};
  for (let i = 1; i < lines.length; i++) {
    const cells = lines[i].split(",").map((c) => c.trim());
    const row = {};
    headers.forEach((h, idx) => (row[h] = cells[idx] || ""));
    if (row.filename) byFilename[row.filename] = row;
  }
  return byFilename;
}

export function resizeImage(file, maxDim = 1600, quality = 0.85) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      let { width, height } = img;
      if (width > maxDim || height > maxDim) {
        const scale = maxDim / Math.max(width, height);
        width = Math.round(width * scale);
        height = Math.round(height * scale);
      }
      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;
      canvas.getContext("2d").drawImage(img, 0, 0, width, height);
      canvas.toBlob((blob) => resolve(blob), "image/jpeg", quality);
    };
    img.onerror = reject;
    img.src = URL.createObjectURL(file);
  });
}

export function statusClass(status) {
  if (status === "match" || status === "pass") return "pass";
  if (status === "review") return "review";
  return "fail";
}

export function stampFor(result) {
  if (!result) return { cls: "fail", label: "Couldn't check" };
  const statuses = (result.comparisons || [])
    .map((c) => c.status)
    .concat(result.government_warning?.match ? "pass" : "fail");
  if (statuses.includes("mismatch") || statuses.includes("fail")) {
    return { cls: "fail", label: "Needs correction" };
  }
  if (statuses.includes("review")) return { cls: "review", label: "Needs a look" };
  return { cls: "pass", label: "Clear" };
}

export function toCsv(items) {
  const rows = [["filename", "field", "application_value", "label_value", "status", "note"]];
  items.forEach((item) => {
    if (!item.result) return;
    (item.result.comparisons || []).forEach((c) => {
      rows.push([item.file.name, c.field, c.application_value, c.label_value, c.status, c.note || ""]);
    });
    rows.push([
      item.file.name,
      "government_warning",
      "",
      "",
      item.result.government_warning.match ? "match" : "mismatch",
      item.result.government_warning.note,
    ]);
  });
  return rows.map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n");
}

/** Runs async jobs over items with a concurrency cap, calling onItemDone as each settles. */
export async function runWithConcurrency(items, worker, concurrency, onItemDone) {
  let idx = 0;
  let active = 0;
  return new Promise((resolve) => {
    function next() {
      if (idx >= items.length && active === 0) return resolve();
      while (active < concurrency && idx < items.length) {
        const item = items[idx++];
        active++;
        worker(item)
          .then((result) => onItemDone(item, result, null))
          .catch((err) => onItemDone(item, null, err))
          .finally(() => {
            active--;
            next();
          });
      }
    }
    next();
  });
}
