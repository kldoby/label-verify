import { useRef, useState } from "react";
import IntakePanel from "./components/IntakePanel.jsx";
import QueuePanel from "./components/QueuePanel.jsx";
import ResultsPanel from "./components/ResultsPanel.jsx";
import { parseCsv, resizeImage, runWithConcurrency } from "./utils.js";

const EMPTY_APPLICATION = { brand_name: "", class_type: "", alcohol_content: "", net_contents: "" };
const CONCURRENCY = 5;

let nextId = 1;

export default function App() {
  const [items, setItems] = useState([]);
  const [busy, setBusy] = useState(false);
  const csvByFilename = useRef({});

  function addFiles(files) {
    if (!files.length) return;
    const newItems = files.map((file) => {
      const csvMatch = csvByFilename.current[file.name] || {};
      return {
        id: `item-${nextId++}`,
        file,
        previewUrl: URL.createObjectURL(file),
        application: { ...EMPTY_APPLICATION, ...csvMatch },
        result: null,
        error: null,
      };
    });
    setItems((prev) => [...prev, ...newItems]);
  }

  function handleCsv(text) {
    const byFilename = parseCsv(text);
    csvByFilename.current = byFilename;
    setItems((prev) =>
      prev.map((item) => {
        const match = byFilename[item.file.name];
        return match ? { ...item, application: { ...item.application, ...match } } : item;
      })
    );
  }

  function handleFieldChange(id, field, value) {
    setItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, application: { ...item.application, [field]: value } } : item))
    );
  }

  async function verifyOne(item) {
    const resizedBlob = await resizeImage(item.file, 1600, 0.85);
    const formData = new FormData();
    formData.append("image", resizedBlob, item.file.name);
    formData.append("application", JSON.stringify(item.application));

    const res = await fetch("/api/verify", { method: "POST", body: formData });
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body.error || `Server error (${res.status})`);
    }
    return res.json();
  }

  async function runBatch() {
    setBusy(true);
    // mark everything as pending so result cards show "checking…"
    setItems((prev) => prev.map((item) => ({ ...item, result: null, error: null })));

    await runWithConcurrency(items, verifyOne, CONCURRENCY, (item, result, err) => {
      setItems((prev) =>
        prev.map((i) =>
          i.id === item.id
            ? { ...i, result: err ? null : result, error: err ? err.message || "Something went wrong." : null }
            : i
        )
      );
    });

    setBusy(false);
  }

  return (
    <>
      <header className="topbar">
        <div className="topbar-inner">
          <span className="seal" aria-hidden="true">⛨</span>
          <div className="topbar-text">
            <h1>Label Review Desk</h1>
            <p>Check label artwork against application data — one at a time, or a whole batch.</p>
          </div>
        </div>
      </header>

      <main className="layout">
        <IntakePanel onAddFiles={addFiles} onCsv={handleCsv} />
        <QueuePanel items={items} onFieldChange={handleFieldChange} onVerifyAll={runBatch} busy={busy} />
        <ResultsPanel items={items} />
      </main>

      <footer className="footer">
        <p>Prototype — nothing uploaded here is stored. Built for the Compliance Division proof-of-concept.</p>
      </footer>
    </>
  );
}
