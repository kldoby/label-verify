const FIELD_DEFS = [
  ["brand_name", "Brand name"],
  ["class_type", "Class / type"],
  ["alcohol_content", "Alcohol content"],
  ["net_contents", "Net contents"],
];

export default function QueuePanel({ items, onFieldChange, onVerifyAll, busy }) {
  if (items.length === 0) return null;

  return (
    <section className="panel queue">
      <h2>2. Confirm what each label should say</h2>
      <p className="hint">Fill in any blanks, then start the check.</p>

      <div className="queue-list">
        {items.map((item) => (
          <div className="queue-item" key={item.id}>
            <img src={item.previewUrl} alt="" />
            <div>
              <div className="queue-filename">{item.file.name}</div>
              <div className="queue-fields">
                {FIELD_DEFS.map(([field, label]) => (
                  <label key={field}>
                    {label}
                    <input
                      value={item.application[field]}
                      placeholder="As written on the application"
                      onChange={(e) => onFieldChange(item.id, field, e.target.value)}
                    />
                  </label>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="queue-actions">
        <button className="btn primary" disabled={busy} onClick={onVerifyAll}>
          {busy ? "Checking…" : "Check all labels"}
        </button>
        <span className="queue-count">
          {items.length} label{items.length === 1 ? "" : "s"} queued
        </span>
      </div>
    </section>
  );
}
