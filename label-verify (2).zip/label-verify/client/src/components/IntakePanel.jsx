import { useRef, useState } from "react";

export default function IntakePanel({ onAddFiles, onCsv }) {
  const fileInputRef = useRef(null);
  const [dragOver, setDragOver] = useState(false);

  function handleDrop(e) {
    e.preventDefault();
    setDragOver(false);
    const files = Array.from(e.dataTransfer.files).filter((f) => f.type.startsWith("image/"));
    onAddFiles(files);
  }

  return (
    <section className="panel intake">
      <h2>1. Add labels</h2>
      <p className="hint">
        Drop in label photos. You can also add a CSV so the application values fill in
        automatically — otherwise you'll type them in for each label.
      </p>

      <div
        className={`dropzone ${dragOver ? "dragover" : ""}`}
        tabIndex={0}
        role="button"
        onClick={() => fileInputRef.current?.click()}
        onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && fileInputRef.current?.click()}
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
      >
        <span className="dropzone-icon" aria-hidden="true">⇪</span>
        <span className="dropzone-text">Drop label images here, or click to choose files</span>
        <span className="dropzone-sub">JPG or PNG · one label per image</span>
      </div>
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        hidden
        onChange={(e) => {
          onAddFiles(Array.from(e.target.files));
          e.target.value = "";
        }}
      />

      <label className="csv-row">
        <span>Optional: application data (CSV)</span>
        <input
          type="file"
          accept=".csv"
          onChange={async (e) => {
            const file = e.target.files[0];
            if (file) onCsv(await file.text());
          }}
        />
      </label>
      <p className="hint small">
        Columns: <code>filename, brand_name, class_type, alcohol_content, net_contents</code>
      </p>
    </section>
  );
}
