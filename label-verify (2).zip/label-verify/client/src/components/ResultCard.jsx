import { statusClass, stampFor } from "../utils.js";

const FIELD_LABELS = {
  brand_name: "Brand name",
  class_type: "Class / type",
  alcohol_content: "Alcohol content",
  net_contents: "Net contents",
};

export default function ResultCard({ item }) {
  if (item.error) {
    return (
      <div className="result-card">
        <div className="result-card-head">
          <img src={item.previewUrl} alt="" />
          <span className="name">{item.file.name}</span>
          <span className="stamp fail">Couldn't check</span>
        </div>
        <div className="quality-note">{item.error}</div>
      </div>
    );
  }

  if (!item.result) {
    return (
      <div className="result-card">
        <div className="result-card-head">
          <img src={item.previewUrl} alt="" />
          <span className="name">{item.file.name}</span>
          <span className="timing">checking…</span>
        </div>
      </div>
    );
  }

  const { result } = item;
  const stamp = stampFor(result);

  return (
    <div className="result-card">
      <div className="result-card-head">
        <img src={item.previewUrl} alt="" />
        <span className="name">{item.file.name}</span>
        <span className={`stamp ${stamp.cls}`}>{stamp.label}</span>
        <span className="timing">{result.elapsed_ms} ms</span>
      </div>

      {result.image_quality_issue && (
        <div className="quality-note">Image quality flag — {result.image_quality_issue}</div>
      )}

      <div className="field-rows">
        {(result.comparisons || []).map((c, i) => {
          const cls = statusClass(c.status);
          return (
            <div className="field-row" key={i}>
              <div className="field-label">{FIELD_LABELS[c.field] || c.field}</div>
              <div className="field-value">{c.application_value}</div>
              <div className="field-value">{c.label_value}</div>
              <div className="field-status">
                <span className={`dot ${cls}`}></span>
                {cls === "pass" ? "Match" : cls === "review" ? "Review" : "Mismatch"}
              </div>
              {c.note && <div className="field-note">{c.note}</div>}
            </div>
          );
        })}

        <div className="field-row">
          <div className="field-label">Government Warning</div>
          <div className="field-value">required text</div>
          <div className="field-value"></div>
          <div className="field-status">
            <span className={`dot ${result.government_warning.match ? "pass" : "fail"}`}></span>
            {result.government_warning.match ? "Match" : "Mismatch"}
          </div>
          <div className="field-note">{result.government_warning.note}</div>
        </div>
      </div>
    </div>
  );
}
