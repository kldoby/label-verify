import ResultCard from "./ResultCard.jsx";
import { stampFor, toCsv } from "../utils.js";

export default function ResultsPanel({ items }) {
  const checked = items.filter((i) => i.result || i.error);
  if (checked.length === 0) return null;

  const clear = checked.filter((i) => i.result && stampFor(i.result).cls === "pass").length;
  const review = checked.filter((i) => i.result && stampFor(i.result).cls === "review").length;
  const fail = checked.filter((i) => i.error || (i.result && stampFor(i.result).cls === "fail")).length;

  function exportCsv() {
    const csv = toCsv(items);
    const blob = new Blob([csv], { type: "text/csv" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "label-review-results.csv";
    a.click();
  }

  return (
    <section className="panel results">
      <div className="results-header">
        <h2>3. Results</h2>
        <div className="results-actions">
          <span className="results-summary">
            {clear} clear · {review} need a look · {fail} need correction
          </span>
          <button className="btn secondary" onClick={exportCsv}>
            Export CSV
          </button>
        </div>
      </div>
      <div className="results-list">
        {items.map((item) => (
          <ResultCard item={item} key={item.id} />
        ))}
      </div>
    </section>
  );
}
