# Label Review Desk — React client

This is a React (Vite) version of the frontend, functionally identical to
the plain HTML/JS version in `../public`, intended for testing component
behavior in isolation and as a base if the team wants to move to a
component framework long-term.

It talks to the same backend in `../server` — nothing about the API
changes.

## Run it

In one terminal, start the backend:

```bash
cd ../server
npm install
npm start        # http://localhost:8787
```

In another terminal, start the React dev server:

```bash
npm install
npm run dev       # http://localhost:5173
```

Vite's dev server proxies `/api/*` requests to `http://localhost:8787`
(see `vite.config.js`), so the app works the same as the static version
without any CORS setup.

## Structure

```
src/
  App.jsx                 — top-level state: queued items, batch run, wiring
  utils.js                — CSV parsing, image resizing, batch concurrency runner
  components/
    IntakePanel.jsx        — drag-and-drop + CSV upload
    QueuePanel.jsx          — editable application fields per queued label
    ResultsPanel.jsx        — summary + CSV export + list of result cards
    ResultCard.jsx           — single label's comparison results
  styles.css               — shared design system (same tokens as the static version)
```

## Building for production

```bash
npm run build
```

Outputs to `dist/`. The Express server in `../server` can be pointed at
this `dist/` folder instead of `../public` if the React version becomes
the primary frontend — change the `express.static(...)` path in
`server/index.js`.
